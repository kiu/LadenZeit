G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.2*
G04 #@! TF.CreationDate,2026-08-03T21:49:44+02:00*
G04 #@! TF.ProjectId,LadenZeitPlate,4c616465-6e5a-4656-9974-506c6174652e,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2) date 2026-08-03 21:49:44*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H4*
X198250000Y-85750000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X103250000Y-114250000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X198250000Y-114250000D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X103250000Y-85750000D03*
G04 #@! TD*
M02*
